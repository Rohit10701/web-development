// index.mjs
import 'esm'; // Enable ECMAScript modules
import AWS from 'aws-sdk';

export const handler = async (event, context) => {
  const ssm = new AWS.SSM();
  const apigatewaymanagementapi = new AWS.ApiGatewayManagementApi({
    apiVersion: '2018-11-29',
    endpoint: 'wss://t7y2w5nfwf.execute-api.eu-north-1.amazonaws.com/production/'
  });

  const instanceId = 'i-09fd244a470aa634f'; // Replace with your EC2 instance ID

  const params = {
    DocumentName: 'AWS-RunShellScript',
    Targets: [
      {
        Key: 'instanceids',
        Values: [instanceId],
      },
    ],
    Parameters: {
      commands: [event.command], // Use the command passed from the React app
    },
  };

  try {
    const data = await ssm.sendCommand(params).promise();

    // Notify connected WebSocket clients about the command execution
    const connectionId = event.requestContext.connectionId;
    await apigatewaymanagementapi.postToConnection({
      ConnectionId: connectionId,
      Data: JSON.stringify({ message: 'Command executed successfully!' }),
    }).promise();

    return { statusCode: 200, body: JSON.stringify(data) };
  } catch (error) {
    console.error('Error sending command:', error);
    return { statusCode: 500, body: JSON.stringify({ error: 'Internal Server Error' }) };
  }
};
